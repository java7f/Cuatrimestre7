package gui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTabbedPane;
import javax.swing.JPanel;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import Tienda.*;
import javax.swing.JScrollPane;

public class happyGUI {

	private JFrame happyTechnologies;
	private JTextField codeField;
	private JTextField nameField;
	private JTextField priceField;
	private JTextField quantityField;
	private JTextField carrierField;
	private JTextField processorField;
	private JTextField romField;
	private JTextField ramField;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private JTextField deleteField;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField newQuantity;
	private final ButtonGroup buttonGroup_1 = new ButtonGroup();
	private final ButtonGroup buttonGroup_2 = new ButtonGroup();
	private JTextField textField_2;
	private final ButtonGroup buttonGroup_3 = new ButtonGroup();
	private JTextField price;
	private TechStore happy= TechStore.getStore();
	private JTextField textField_3;
	private JTable computers;
	private JTable phones;
	private JTable computerTable;
	private JTable table;
	private JTextField tableCode;
	private final ButtonGroup buttonGroup_4 = new ButtonGroup();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					happyGUI window = new happyGUI();
					window.happyTechnologies.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public happyGUI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		happyTechnologies = new JFrame();
		happyTechnologies.getContentPane().setBackground(new Color(0, 51, 51));
		happyTechnologies.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 14));
		happyTechnologies.setTitle("Happy Technologies");
		happyTechnologies.setBounds(100, 100, 701, 505);
		happyTechnologies.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		happyTechnologies.getContentPane().setLayout(null);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBorder(null);
		tabbedPane.setBackground(new Color(51, 51, 51));
		tabbedPane.setBounds(10, 60, 665, 374);
		happyTechnologies.getContentPane().add(tabbedPane);
		
		JPanel insertData = new JPanel();
		insertData.setBackground(new Color(0, 102, 102));
		tabbedPane.addTab("Insert product", null, insertData, null);
		insertData.setLayout(null);
		
		JLabel lblCode = new JLabel("Code:");
		lblCode.setForeground(new Color(0, 0, 0));
		lblCode.setBackground(new Color(255, 255, 255));
		lblCode.setFont(new Font("Microsoft JhengHei UI", Font.BOLD, 14));
		lblCode.setBounds(20, 22, 53, 19);
		insertData.add(lblCode);
		
		codeField = new JTextField();
		codeField.setBounds(133, 23, 135, 20);
		insertData.add(codeField);
		codeField.setColumns(10);
		
		JLabel lblProductName = new JLabel("Product Name:");
		lblProductName.setForeground(new Color(0, 0, 0));
		lblProductName.setBackground(new Color(255, 255, 255));
		lblProductName.setFont(new Font("Microsoft JhengHei UI", Font.BOLD, 14));
		lblProductName.setBounds(20, 72, 103, 19);
		insertData.add(lblProductName);
		
		nameField = new JTextField();
		nameField.setBounds(133, 71, 135, 20);
		insertData.add(nameField);
		nameField.setColumns(10);
		
		JLabel lblPrice = new JLabel("Price:");
		lblPrice.setForeground(new Color(0, 0, 0));
		lblPrice.setBackground(new Color(255, 255, 255));
		lblPrice.setFont(new Font("Microsoft JhengHei UI", Font.BOLD, 14));
		lblPrice.setBounds(20, 124, 46, 19);
		insertData.add(lblPrice);
		
		priceField = new JTextField();
		priceField.setBounds(133, 125, 86, 20);
		insertData.add(priceField);
		priceField.setColumns(10);
		
		JLabel lblQuantity = new JLabel("Quantity:");
		lblQuantity.setForeground(new Color(0, 0, 0));
		lblQuantity.setBackground(new Color(255, 255, 255));
		lblQuantity.setFont(new Font("Microsoft JhengHei UI", Font.BOLD, 14));
		lblQuantity.setBounds(20, 173, 73, 19);
		insertData.add(lblQuantity);
		
		quantityField = new JTextField();
		quantityField.setColumns(10);
		quantityField.setBounds(133, 174, 86, 20);
		insertData.add(quantityField);
		
		JComboBox productType = new JComboBox();
		productType.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 14));
		productType.setModel(new DefaultComboBoxModel(new String[] {"Select", "Phone", "Computer"}));
		productType.setBounds(133, 227, 103, 20);
		insertData.add(productType);
		
		JLabel lblCarrier = new JLabel("Carrier:");
		lblCarrier.setVisible(false);
		lblCarrier.setForeground(new Color(0, 0, 0));
		lblCarrier.setBackground(new Color(255, 255, 255));
		lblCarrier.setFont(new Font("Microsoft JhengHei UI", Font.BOLD, 14));
		lblCarrier.setBounds(20, 273, 73, 19);
		insertData.add(lblCarrier);
		
		carrierField = new JTextField();
		carrierField.setColumns(10);
		carrierField.setBounds(133, 274, 135, 20);
		insertData.add(carrierField);
		carrierField.setVisible(false);
		
		JLabel lblProcessor = new JLabel("Processor:");
		lblProcessor.setVisible(false);
		lblProcessor.setForeground(Color.BLACK);
		lblProcessor.setFont(new Font("Microsoft JhengHei UI", Font.BOLD, 14));
		lblProcessor.setBackground(Color.WHITE);
		lblProcessor.setBounds(315, 26, 73, 19);
		insertData.add(lblProcessor);
		
		processorField = new JTextField();
		processorField.setColumns(10);
		processorField.setBounds(422, 23, 135, 20);
		insertData.add(processorField);
		processorField.setVisible(false);
		
		JLabel lblRom = new JLabel("ROM:");
		lblRom.setVisible(false);
		lblRom.setForeground(Color.BLACK);
		lblRom.setFont(new Font("Microsoft JhengHei UI", Font.BOLD, 14));
		lblRom.setBackground(Color.WHITE);
		lblRom.setBounds(315, 72, 46, 19);
		insertData.add(lblRom);
		
		romField = new JTextField();
		romField.setColumns(10);
		romField.setBounds(422, 72, 86, 20);
		insertData.add(romField);
		romField.setVisible(false);
		
		JLabel lblRam = new JLabel("RAM:");
		lblRam.setVisible(false);
		lblRam.setForeground(Color.BLACK);
		lblRam.setFont(new Font("Microsoft JhengHei UI", Font.BOLD, 14));
		lblRam.setBackground(Color.WHITE);
		lblRam.setBounds(315, 124, 46, 19);
		insertData.add(lblRam);
		
		ramField = new JTextField();
		ramField.setColumns(10);
		ramField.setBounds(422, 124, 86, 20);
		insertData.add(ramField);
		ramField.setVisible(false);
		
		JLabel lblProductAdded = new JLabel("Product added");
		lblProductAdded.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 12));
		lblProductAdded.setForeground(new Color(0, 204, 0));
		lblProductAdded.setBounds(439, 303, 86, 19);
		insertData.add(lblProductAdded);
		tabbedPane.setForegroundAt(0, new Color(0, 0, 0));
		tabbedPane.setBackgroundAt(0, new Color(102, 102, 102));
		lblProductAdded.setVisible(false);
		
		productType.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (productType.getSelectedItem().equals("Phone")) {
					lblCarrier.setVisible(true);
					carrierField.setVisible(true);
					lblProcessor.setVisible(false);
					lblRom.setVisible(false);
					lblRam.setVisible(false);
					processorField.setVisible(false);
					romField.setVisible(false);
					ramField.setVisible(false);
				}
				else {
					lblCarrier.setVisible(false);
					carrierField.setVisible(false);
					lblProcessor.setVisible(true);
					lblRom.setVisible(true);
					lblRam.setVisible(true);
					processorField.setVisible(true);
					romField.setVisible(true);
					ramField.setVisible(true);
				}
			}
		});
		
		JButton btnAddProduct = new JButton("Add product");
		btnAddProduct.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (productType.getSelectedItem().equals("Phone")) {
					Phone phone= new Phone(codeField.getText(), nameField.getText(), Double.parseDouble(priceField.getText()), Integer.parseInt(quantityField.getText()), carrierField.getText());
					try {
						happy.addPhone(phone);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
				else {
					Computer computer= new Computer(codeField.getText(), nameField.getText(), Double.parseDouble(priceField.getText()), Integer.parseInt(quantityField.getText()), processorField.getText(), romField.getText(), ramField.getText());
					try {
						happy.addComputer(computer);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
				
				codeField.setText(null);
				nameField.setText(null);
				priceField.setText(null);
				quantityField.setText(null);
				carrierField.setText(null);
				processorField.setText(null);
				romField.setText(null);
				ramField.setText(null);
				lblProductAdded.setVisible(true);
			}
		});
		btnAddProduct.setFont(new Font("Microsoft JhengHei UI", Font.BOLD, 12));
		btnAddProduct.setBounds(419, 269, 117, 23);
		insertData.add(btnAddProduct);
		
		JLabel lblProductType = new JLabel("Product Type:");
		lblProductType.setForeground(Color.BLACK);
		lblProductType.setFont(new Font("Microsoft JhengHei UI", Font.BOLD, 14));
		lblProductType.setBackground(Color.WHITE);
		lblProductType.setBounds(20, 228, 103, 19);
		insertData.add(lblProductType);
		
		
		JPanel deleteProduct = new JPanel();
		deleteProduct.setBackground(new Color(0, 102, 102));
		tabbedPane.addTab("Delete product", null, deleteProduct, null);
		deleteProduct.setLayout(null);
		
		JRadioButton rdbtnPhone = new JRadioButton("Phone");
		rdbtnPhone.setFont(new Font("Microsoft JhengHei UI", Font.BOLD, 12));
		rdbtnPhone.setForeground(new Color(0, 0, 0));
		rdbtnPhone.setBackground(new Color(0, 102, 102));
		buttonGroup.add(rdbtnPhone);
		rdbtnPhone.setBounds(194, 83, 109, 23);
		deleteProduct.add(rdbtnPhone);
		
		JRadioButton rdbtnComputer = new JRadioButton("Computer");
		rdbtnComputer.setFont(new Font("Microsoft JhengHei UI", Font.BOLD, 12));
		rdbtnComputer.setForeground(new Color(0, 0, 0));
		rdbtnComputer.setBackground(new Color(0, 102, 102));
		buttonGroup.add(rdbtnComputer);
		rdbtnComputer.setBounds(317, 83, 109, 23);
		deleteProduct.add(rdbtnComputer);
		
		JLabel lblSelect = new JLabel("Select the type of product:");
		lblSelect.setForeground(Color.BLACK);
		lblSelect.setFont(new Font("Microsoft JhengHei UI", Font.BOLD, 18));
		lblSelect.setBackground(Color.WHITE);
		lblSelect.setBounds(182, 23, 250, 42);
		deleteProduct.add(lblSelect);
		
		JLabel lblProductCode = new JLabel("Product Code:");
		lblProductCode.setForeground(Color.BLACK);
		lblProductCode.setFont(new Font("Microsoft JhengHei UI", Font.BOLD, 18));
		lblProductCode.setBackground(Color.WHITE);
		lblProductCode.setBounds(229, 150, 134, 42);
		deleteProduct.add(lblProductCode);
		
		deleteField = new JTextField();
		deleteField.setBounds(217, 203, 155, 20);
		deleteProduct.add(deleteField);
		deleteField.setColumns(10);
		
		JButton btnDeleteProduct = new JButton("Delete product");
		btnDeleteProduct.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (rdbtnPhone.isSelected()) {
					try {
						happy.deletePhone(deleteField.getText());
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
				else if (rdbtnComputer.isSelected()) {
					try {
						happy.deleteComputer(deleteField.getText());
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
				deleteField.setText(null);
			}
		});
		btnDeleteProduct.setFont(new Font("Microsoft JhengHei UI", Font.BOLD, 12));
		btnDeleteProduct.setBounds(229, 277, 134, 23);
		deleteProduct.add(btnDeleteProduct);
		tabbedPane.setForegroundAt(1, new Color(0, 0, 0));
		tabbedPane.setBackgroundAt(1, new Color(102, 102, 102));
		
		JPanel viewProduct = new JPanel();
		viewProduct.setBackground(new Color(0, 102, 102));
		tabbedPane.addTab("View product", null, viewProduct, null);
		viewProduct.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(10, 110, 640, 225);
		viewProduct.add(panel);
		panel.setLayout(null);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(10, 141, 620, 73);
		panel.add(scrollPane_1);
		
		computers = new JTable();
		scrollPane_1.setViewportView(computers);
		computers.setFillsViewportHeight(true);
		computers.setColumnSelectionAllowed(true);
		computers.setCellSelectionEnabled(true);
		computers.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Code", "Name", "Price", "Quantity", "Processor", "ROM", "RAM"
			}
		));
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 11, 620, 73);
		panel.add(scrollPane);
		
		phones = new JTable();
		scrollPane.setViewportView(phones);
		phones.setFillsViewportHeight(true);
		phones.setColumnSelectionAllowed(true);
		phones.setCellSelectionEnabled(true);
		phones.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Code", "Name", "Price", "Quantity", "Carrier"
			}
		));
		
		JLabel label_7 = new JLabel("Select the type of product:");
		label_7.setForeground(Color.BLACK);
		label_7.setFont(new Font("Microsoft JhengHei UI", Font.BOLD, 18));
		label_7.setBackground(Color.WHITE);
		label_7.setBounds(10, 11, 250, 42);
		viewProduct.add(label_7);
		
		JRadioButton tablePhone = new JRadioButton("Phone");
		buttonGroup_4.add(tablePhone);
		tablePhone.setForeground(Color.BLACK);
		tablePhone.setFont(new Font("Microsoft JhengHei UI", Font.BOLD, 12));
		tablePhone.setBackground(new Color(0, 102, 102));
		tablePhone.setBounds(22, 71, 109, 23);
		viewProduct.add(tablePhone);
		
		JRadioButton tableComp = new JRadioButton("Computer");
		buttonGroup_4.add(tableComp);
		tableComp.setForeground(Color.BLACK);
		tableComp.setFont(new Font("Microsoft JhengHei UI", Font.BOLD, 12));
		tableComp.setBackground(new Color(0, 102, 102));
		tableComp.setBounds(145, 71, 109, 23);
		viewProduct.add(tableComp);
		
		JLabel label_8 = new JLabel("Product Code:");
		label_8.setForeground(Color.BLACK);
		label_8.setFont(new Font("Microsoft JhengHei UI", Font.BOLD, 18));
		label_8.setBackground(Color.WHITE);
		label_8.setBounds(306, 11, 134, 42);
		viewProduct.add(label_8);
		
		tableCode = new JTextField();
		tableCode.setColumns(10);
		tableCode.setBounds(293, 73, 155, 20);
		viewProduct.add(tableCode);
		
		JButton btnShowProduct = new JButton("Show Product");
		btnShowProduct.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent arg0) {
				if (tablePhone.isSelected()) {
					try {
						DefaultTableModel model= (DefaultTableModel) phones.getModel();
			       		Connection con= ConnectionConfiguration.getConnectionLocal();
						PreparedStatement updatingProduct= con.prepareStatement("Select * from celulares where code= '"+ tableCode.getText() + "'");
						ResultSet resultSet;
						resultSet= updatingProduct.executeQuery();
						if (resultSet.next()) {
							Object[] data= {resultSet.getObject("code"), resultSet.getObject("product_name"), resultSet.getObject("price"), resultSet.getObject("quantity"), resultSet.getObject("carrier")};
							model.addRow(data);
						}
					} catch (Exception e) {

						try {
							DefaultTableModel model= (DefaultTableModel) phones.getModel();
							Connection con= ConnectionConfiguration.getRemoteConnection();
							PreparedStatement updatingProduct= con.prepareStatement("Select * from celulares where code= '"+ tableCode.getText() + "'");
							ResultSet resultSet;
							resultSet= updatingProduct.executeQuery();
							if (resultSet.next()) {
								Object[] data= {resultSet.getObject("code"), resultSet.getObject("product_name"), resultSet.getObject("price"), resultSet.getObject("quantity"), resultSet.getObject("carrier")};
								model.addRow(data);
							}
						} catch (Exception e2){
							System.out.println(e2);
						}

			        	e.printStackTrace();
					}
				}
				else if (tableComp.isSelected()) {
					try {
						DefaultTableModel model= (DefaultTableModel) computers.getModel();
			       		Connection con= ConnectionConfiguration.getConnectionLocal();
						PreparedStatement updatingProduct= con.prepareStatement("Select * from computadoras where code= '"+ tableCode.getText() + "'");
						ResultSet resultSet;
						resultSet= updatingProduct.executeQuery();
						if (resultSet.next()) {
							Object[] data= {resultSet.getObject("code"), resultSet.getObject("product_name"), resultSet.getObject("price"), resultSet.getObject("quantity"), resultSet.getObject("processor"), resultSet.getString("rom"), resultSet.getString("ram")};
							model.addRow(data);
						}
					} catch (Exception e) {
						try{
							DefaultTableModel model= (DefaultTableModel) computers.getModel();
							Connection con= ConnectionConfiguration.getRemoteConnection();
							PreparedStatement updatingProduct= con.prepareStatement("Select * from computadoras where code= '"+ tableCode.getText() + "'");
							ResultSet resultSet;
							resultSet= updatingProduct.executeQuery();
							if (resultSet.next()) {
								Object[] data= {resultSet.getObject("code"), resultSet.getObject("product_name"), resultSet.getObject("price"), resultSet.getObject("quantity"), resultSet.getObject("processor"), resultSet.getString("rom"), resultSet.getString("ram")};
								model.addRow(data);
							}
						} catch (Exception e2){
							System.out.println(e2);
						}
			        	e.printStackTrace();
					}
				}
			}
		});
		btnShowProduct.setFont(new Font("Microsoft JhengHei UI", Font.BOLD, 12));
		btnShowProduct.setBounds(494, 49, 134, 23);
		viewProduct.add(btnShowProduct);
		tabbedPane.setForegroundAt(2, new Color(0, 0, 0));
		tabbedPane.setBackgroundAt(2, new Color(102, 102, 102));
		
		JPanel sellProduct = new JPanel();
		sellProduct.setBackground(new Color(0, 102, 102));
		tabbedPane.addTab("Sell Product", null, sellProduct, null);
		tabbedPane.setForegroundAt(3, new Color(0, 0, 0));
		tabbedPane.setBackgroundAt(3, new Color(102, 102, 102));
		sellProduct.setLayout(null);
		
		JLabel label = new JLabel("Select the type of product:");
		label.setForeground(Color.BLACK);
		label.setFont(new Font("Microsoft JhengHei UI", Font.BOLD, 18));
		label.setBackground(Color.WHITE);
		label.setBounds(166, 22, 250, 42);
		sellProduct.add(label);
		
		JRadioButton radioButton = new JRadioButton("Phone");
		buttonGroup_2.add(radioButton);
		radioButton.setForeground(Color.BLACK);
		radioButton.setFont(new Font("Microsoft JhengHei UI", Font.BOLD, 12));
		radioButton.setBackground(new Color(0, 102, 102));
		radioButton.setBounds(166, 71, 109, 23);
		sellProduct.add(radioButton);
		
		JRadioButton radioButton_1 = new JRadioButton("Computer");
		buttonGroup_2.add(radioButton_1);
		radioButton_1.setForeground(Color.BLACK);
		radioButton_1.setFont(new Font("Microsoft JhengHei UI", Font.BOLD, 12));
		radioButton_1.setBackground(new Color(0, 102, 102));
		radioButton_1.setBounds(289, 71, 109, 23);
		sellProduct.add(radioButton_1);
		
		JLabel label_1 = new JLabel("Product Code:");
		label_1.setForeground(Color.BLACK);
		label_1.setFont(new Font("Microsoft JhengHei UI", Font.BOLD, 18));
		label_1.setBackground(Color.WHITE);
		label_1.setBounds(208, 101, 133, 42);
		sellProduct.add(label_1);
		
		textField = new JTextField();
		textField.setColumns(10);
		textField.setBounds(189, 138, 155, 20);
		sellProduct.add(textField);
		
		JLabel label_2 = new JLabel("Price:");
		label_2.setForeground(Color.BLACK);
		label_2.setFont(new Font("Microsoft JhengHei UI", Font.BOLD, 14));
		label_2.setBackground(Color.WHITE);
		label_2.setBounds(370, 243, 46, 19);
		sellProduct.add(label_2);
		
		JLabel precio = new JLabel("");
		precio.setForeground(Color.BLACK);
		precio.setFont(new Font("Microsoft JhengHei UI", Font.BOLD, 14));
		precio.setBackground(Color.WHITE);
		precio.setBounds(416, 243, 56, 19);
		sellProduct.add(precio);
		
		JButton btnSellProduct = new JButton("Sell Product");
		btnSellProduct.setFont(new Font("Microsoft JhengHei UI", Font.BOLD, 12));
		btnSellProduct.setBounds(198, 287, 134, 23);
		sellProduct.add(btnSellProduct);
		
		JLabel lblItemQuantity = new JLabel("Item quantity");
		lblItemQuantity.setForeground(Color.BLACK);
		lblItemQuantity.setFont(new Font("Microsoft JhengHei UI", Font.BOLD, 14));
		lblItemQuantity.setBackground(Color.WHITE);
		lblItemQuantity.setBounds(158, 169, 92, 19);
		sellProduct.add(lblItemQuantity);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(290, 170, 51, 20);
		sellProduct.add(textField_2);
		
		JLabel lblProduct = new JLabel("Product:");
		lblProduct.setForeground(Color.BLACK);
		lblProduct.setFont(new Font("Microsoft JhengHei UI", Font.BOLD, 14));
		lblProduct.setBackground(Color.WHITE);
		lblProduct.setBounds(89, 243, 67, 19);
		sellProduct.add(lblProduct);
		
		JLabel productInformation = new JLabel("");
		productInformation.setForeground(Color.BLACK);
		productInformation.setFont(new Font("Microsoft JhengHei UI", Font.BOLD, 14));
		productInformation.setBackground(Color.WHITE);
		productInformation.setBounds(156, 243, 141, 19);
		sellProduct.add(productInformation);
		
		btnSellProduct.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (radioButton.isSelected()) {
					try {
			       		Connection con= ConnectionConfiguration.getConnectionLocal();
						PreparedStatement updatingProduct= con.prepareStatement("Select * from celulares where code= '"+ textField.getText() + "'");
						ResultSet resultSet;
						resultSet= updatingProduct.executeQuery();
						if (resultSet.next()) {
							String newQuantity= resultSet.getString("product_name");
							double getPrice= resultSet.getDouble("price");
							productInformation.setText(newQuantity);
							precio.setText(String.valueOf(getPrice));
						}
					} catch (Exception ex) {
						try {
							Connection con= ConnectionConfiguration.getRemoteConnection();
							PreparedStatement updatingProduct= con.prepareStatement("Select * from celulares where code= '"+ textField.getText() + "'");
							ResultSet resultSet;
							resultSet= updatingProduct.executeQuery();
							if (resultSet.next()) {
								String newQuantity= resultSet.getString("product_name");
								double getPrice= resultSet.getDouble("price");
								productInformation.setText(newQuantity);
								precio.setText(String.valueOf(getPrice));
							}
						} catch (Exception ex2) {
							System.out.println(ex2);
						}
			        	ex.printStackTrace();
					}


					try {
						happy.sellPhone(textField.getText(), Integer.parseInt(textField_2.getText()));
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
				else if (radioButton_1.isSelected()) {
					try {
			       		Connection con= ConnectionConfiguration.getConnectionLocal();
						PreparedStatement updatingProduct= con.prepareStatement("Select * from computadoras where code= '"+ textField.getText() + "'");
						ResultSet resultSet;
						resultSet= updatingProduct.executeQuery();
						if (resultSet.next()) {
							String newQuantity= resultSet.getString("product_name");
							double getPrice= resultSet.getDouble("price");
							productInformation.setText(newQuantity);
							precio.setText(String.valueOf(getPrice));
						}
					} catch (Exception ex) {
						try {
							Connection con= ConnectionConfiguration.getRemoteConnection();
							PreparedStatement updatingProduct= con.prepareStatement("Select * from computadoras where code= '"+ textField.getText() + "'");
							ResultSet resultSet;
							resultSet= updatingProduct.executeQuery();
							if (resultSet.next()) {
								String newQuantity= resultSet.getString("product_name");
								double getPrice= resultSet.getDouble("price");
								productInformation.setText(newQuantity);
								precio.setText(String.valueOf(getPrice));
							}
						} catch (Exception ex2) {
							// TODO Auto-generated catch block
							ex2.printStackTrace();
						}
			        	ex.printStackTrace();
					}

					try {
						happy.sellComputer(textField.getText(), Integer.parseInt(textField_2.getText()));
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
			}
			
		});
		
		JPanel restock = new JPanel();
		restock.setBackground(new Color(0, 102, 102));
		tabbedPane.addTab("Restock product", null, restock, null);
		restock.setLayout(null);
		
		JLabel label_3 = new JLabel("Select the type of product:");
		label_3.setForeground(Color.BLACK);
		label_3.setFont(new Font("Microsoft JhengHei UI", Font.BOLD, 18));
		label_3.setBackground(Color.WHITE);
		label_3.setBounds(180, 31, 250, 42);
		restock.add(label_3);
		
		JRadioButton radioButton_2 = new JRadioButton("Phone");
		buttonGroup_1.add(radioButton_2);
		radioButton_2.setForeground(Color.BLACK);
		radioButton_2.setFont(new Font("Microsoft JhengHei UI", Font.BOLD, 12));
		radioButton_2.setBackground(new Color(0, 102, 102));
		radioButton_2.setBounds(190, 80, 109, 23);
		restock.add(radioButton_2);
		
		JRadioButton radioButton_3 = new JRadioButton("Computer");
		buttonGroup_1.add(radioButton_3);
		radioButton_3.setForeground(Color.BLACK);
		radioButton_3.setFont(new Font("Microsoft JhengHei UI", Font.BOLD, 12));
		radioButton_3.setBackground(new Color(0, 102, 102));
		radioButton_3.setBounds(321, 80, 109, 23);
		restock.add(radioButton_3);
		
		JLabel label_4 = new JLabel("Product Code:");
		label_4.setForeground(Color.BLACK);
		label_4.setFont(new Font("Microsoft JhengHei UI", Font.BOLD, 18));
		label_4.setBackground(Color.WHITE);
		label_4.setBounds(226, 127, 133, 42);
		restock.add(label_4);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(211, 166, 155, 20);
		restock.add(textField_1);
		
		JLabel lblNewQuantity = new JLabel("New quantity");
		lblNewQuantity.setForeground(Color.BLACK);
		lblNewQuantity.setFont(new Font("Microsoft JhengHei UI", Font.BOLD, 14));
		lblNewQuantity.setBackground(Color.WHITE);
		lblNewQuantity.setBounds(239, 197, 92, 19);
		restock.add(lblNewQuantity);
		
		newQuantity = new JTextField();
		newQuantity.setColumns(10);
		newQuantity.setBounds(239, 227, 86, 20);
		restock.add(newQuantity);
		
		JButton btnRestockProduct = new JButton("Restock product");
		btnRestockProduct.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (radioButton_2.isSelected()) {
					try {
						happy.restockPhone(textField_1.getText(), Integer.parseInt(newQuantity.getText()));
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
				else if (radioButton_3.isSelected()) {
					try {
						happy.restockComputer(textField_1.getText(), Integer.parseInt(newQuantity.getText()));
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
			}
		});
		btnRestockProduct.setFont(new Font("Microsoft JhengHei UI", Font.BOLD, 12));
		btnRestockProduct.setBounds(225, 301, 134, 23);
		restock.add(btnRestockProduct);
		tabbedPane.setForegroundAt(4, new Color(0, 0, 0));
		tabbedPane.setBackgroundAt(4, new Color(102, 102, 102));
		
		JPanel modifyProduct = new JPanel();
		modifyProduct.setBackground(new Color(0, 102, 102));
		tabbedPane.addTab("Modify product", null, modifyProduct, null);
		tabbedPane.setForegroundAt(5, new Color(0, 0, 0));
		tabbedPane.setBackgroundAt(5, new Color(102, 102, 102));
		modifyProduct.setLayout(null);
		
		JLabel label_5 = new JLabel("Select the type of product:");
		label_5.setForeground(Color.BLACK);
		label_5.setFont(new Font("Microsoft JhengHei UI", Font.BOLD, 18));
		label_5.setBackground(Color.WHITE);
		label_5.setBounds(170, 26, 250, 42);
		modifyProduct.add(label_5);
		
		JRadioButton radioButton_4 = new JRadioButton("Phone");
		buttonGroup_3.add(radioButton_4);
		radioButton_4.setForeground(Color.BLACK);
		radioButton_4.setFont(new Font("Microsoft JhengHei UI", Font.BOLD, 12));
		radioButton_4.setBackground(new Color(0, 102, 102));
		radioButton_4.setBounds(186, 75, 109, 23);
		modifyProduct.add(radioButton_4);
		
		JRadioButton radioButton_5 = new JRadioButton("Computer");
		buttonGroup_3.add(radioButton_5);
		radioButton_5.setForeground(Color.BLACK);
		radioButton_5.setFont(new Font("Microsoft JhengHei UI", Font.BOLD, 12));
		radioButton_5.setBackground(new Color(0, 102, 102));
		radioButton_5.setBounds(297, 75, 109, 23);
		modifyProduct.add(radioButton_5);
		
		JLabel lblNewPrice = new JLabel("New price");
		lblNewPrice.setForeground(Color.BLACK);
		lblNewPrice.setFont(new Font("Microsoft JhengHei UI", Font.BOLD, 14));
		lblNewPrice.setBackground(Color.WHITE);
		lblNewPrice.setBounds(140, 217, 75, 19);
		modifyProduct.add(lblNewPrice);
		
		price = new JTextField();
		price.setColumns(10);
		price.setBounds(253, 218, 86, 20);
		modifyProduct.add(price);
		
		JLabel label_6 = new JLabel("Product Code:");
		label_6.setForeground(Color.BLACK);
		label_6.setFont(new Font("Microsoft JhengHei UI", Font.BOLD, 18));
		label_6.setBackground(Color.WHITE);
		label_6.setBounds(240, 124, 133, 42);
		modifyProduct.add(label_6);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(225, 163, 155, 20);
		modifyProduct.add(textField_3);
		
		JButton btnModify = new JButton("Modify");
		btnModify.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (radioButton_4.isSelected()) {
					try {
						happy.updatePhone(textField_3.getText(), Double.parseDouble(price.getText()));
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
				else if (radioButton_5.isSelected()) {
					try {
						happy.updateComputer(textField_3.getText(), Double.parseDouble(price.getText()));
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
			}
		});
		btnModify.setFont(new Font("Microsoft JhengHei UI", Font.BOLD, 12));
		btnModify.setBounds(225, 292, 125, 23);
		modifyProduct.add(btnModify);
		
		
		JLabel lblHappyTechnologies = new JLabel("Happy Technologies");
		lblHappyTechnologies.setBackground(Color.WHITE);
		lblHappyTechnologies.setFont(new Font("Rockwell Condensed", Font.BOLD, 23));
		lblHappyTechnologies.setForeground(Color.WHITE);
		lblHappyTechnologies.setBounds(45, 11, 192, 55);
		happyTechnologies.getContentPane().add(lblHappyTechnologies);
		
		
	}
}
