package Tienda;
public class Computer extends Product {

    private String processor;
    private String ram;
    private String rom;


    public Computer(String code, String name, double price, int quantity, String processor, String ram, String rom) {
        super(code, name, price, quantity);
        this.processor = processor;
        this.ram = ram;
        this.rom = rom;
    }

    public String getProcessor() {
        return processor;
    }

    public void setProcessor(String processor) {
        this.processor = processor;
    }

    public String getRam() {
        return ram;
    }

    public void setRam(String ram) {
        this.ram = ram;
    }

    public String getRom() {
        return rom;
    }

    public void setRom(String rom) {
        this.rom = rom;
    }

    @Override
    public void printDetails() {
        System.out.println("Product: " + getName() + "\n");
        System.out.println("Code: " + getCode() + "\n");
        System.out.println("Price: " + getPrice() + "\n");
        System.out.println("Quantity: " + getQuantity() + "\n");
        System.out.println("Processor: " + getProcessor() + "\n");
        System.out.println("RAM: " + getRam() + "\n");
        System.out.println("ROM: " + getRom() + "\n");
    }
}
