package Tienda;
public class Phone extends Product {

    private String seller;

    public Phone(String code, String name, double price, int quantity, String seller) {
        super(code, name, price, quantity);
        this.seller= seller;
    }

    public String getSeller() {
        return seller;
    }

    public void setSeller(String seller) {
        this.seller = seller;
    }

    @Override
    public void printDetails() {
        System.out.println("Product: " + getName() + "\n");
        System.out.println("Code: " + getCode() + "\n");
        System.out.println("Price: " + getPrice() + "\n");
        System.out.println("Quantity: " + getQuantity() + "\n");
        System.out.println("Seller: " + getSeller());
    }
}
