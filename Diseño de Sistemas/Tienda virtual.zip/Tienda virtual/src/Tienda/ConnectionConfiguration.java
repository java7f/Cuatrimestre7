package Tienda;
import java.sql.Connection;
import java.sql.DriverManager;

public class ConnectionConfiguration {

	 public static Connection getConnectionLocal() throws Exception
	 {
	        Connection connection = null;

	        try{
	            Class.forName("com.mysql.jdbc.Driver");
				connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/tienda?useSSL=true","root","Manchester01");
	        }
	        catch (Exception e){
	            e.printStackTrace();
	        }
	        return connection;
	    }

	  public static Connection getRemoteConnection() throws Exception
	  {
		  Connection connection = null;

		  try{
			  Class.forName("com.mysql.jdbc.Driver");
			  connection = DriverManager.getConnection("jdbc:mysql://javadb.c8q3gbpo96xd.us-east-2.rds.amazonaws.com:3306/tienda2?useSSL=false","java7f","Manchester01");
		  }
		  catch (Exception e){
			  e.printStackTrace();
		  }
		  return connection;
	  }

}

