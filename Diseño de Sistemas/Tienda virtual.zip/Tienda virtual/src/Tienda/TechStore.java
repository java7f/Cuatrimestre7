package Tienda;
import util.FileRW;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.*;

public class TechStore{

    private static TechStore store;
    private boolean isLocalConnected;
    private boolean isRemoteConnected;
    public FileRW fileWriter;

    private TechStore() {
        Connection connection1 = null;
        Connection connection2 = null;
        fileWriter = new FileRW();

        //Probando la base de datos local
        try{
            connection1 = ConnectionConfiguration.getConnectionLocal();

        } catch (Exception e){
            System.out.println(e);
        } finally {
            if(connection1 != null){
				System.out.println("Connected to local data base");
				isLocalConnected = true;
                try {
                    connection1.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }

        //Probando la base de datos remota
		try{
			connection2 = ConnectionConfiguration.getRemoteConnection();

		} catch (Exception e){
			e.printStackTrace();
		} finally {
			if(connection2 != null){
				System.out.println("Connected to remote data base");
				isRemoteConnected = true;
				try {
					connection2.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
    }

    public static TechStore getStore()
    {
        if(store == null)
        {
            store= new TechStore();
        }
        return store;
    }

    public void addPhone(Phone product) throws Exception{
		Connection con = null;
		String query = "Insert into celulares(code, product_name, price, quantity, carrier) values('" + product.getCode() + "', '" + product.getName() + "', '" + product.getPrice() + "', '" + product.getQuantity() + "', '" + product.getSeller() + "')";
		updateDatabase();
		try {
			con = ConnectionConfiguration.getConnectionLocal();
			PreparedStatement addingProduct = con.prepareStatement(query);
			addingProduct.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (con != null)
				isLocalConnected = true;
			else{
				isLocalConnected = false;
				fileWriter.writeQuery(query, "localDB.txt");
			}


			try {
				con = ConnectionConfiguration.getRemoteConnection();
				PreparedStatement addingProduct = con.prepareStatement(query);
				addingProduct.executeUpdate();
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				if (con != null)
					isRemoteConnected = true;
				else{
					isRemoteConnected = false;
					fileWriter.writeQuery(query, "remoteDB.txt");
				}
			}
		}
	}
        

    
    public void addComputer(Computer product) throws Exception
    {
		Connection con = null;
		updateDatabase();
		String query = "Insert into computadoras(code, product_name, price, quantity, processor, rom, ram) values('"+product.getCode()+"', '"+product.getName()+"', '"+product.getPrice()+"', '"+product.getQuantity()+"', '"+product.getProcessor()+"', '"+product.getRom()+"', '"+product.getRam()+"')";
        try {
			con= ConnectionConfiguration.getConnectionLocal();
			PreparedStatement addingProduct= con.prepareStatement(query);
			addingProduct.executeUpdate();
		} catch (SQLException e) {
        	e.printStackTrace();
		} finally {
			if (con != null)
				isLocalConnected = true;
			else{
				isLocalConnected = false;
				fileWriter.writeQuery(query, "localDB.txt");
			}
			try {
				con= ConnectionConfiguration.getRemoteConnection();
				PreparedStatement addingProduct= con.prepareStatement(query);
				addingProduct.executeUpdate();
			} catch (SQLException e) {
				e.printStackTrace();
			}finally {
				if (con != null)
					isRemoteConnected = true;
				else{
					isRemoteConnected = false;
					fileWriter.writeQuery(query, "remoteDB.txt");
				}
			}
		}

    }

    public void deletePhone(String code) throws Exception
    {
		Connection con = null;
		updateDatabase();
		String query = "delete from celulares where code= '"+ code+"'";
		try {

			con= ConnectionConfiguration.getConnectionLocal();
			PreparedStatement deleteProduct= con.prepareStatement(query);
			deleteProduct.executeUpdate();
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			if (con != null)
				isLocalConnected = true;
			else{
				isLocalConnected = false;
				fileWriter.writeQuery(query, "localDB.txt");
			}
			try {
				con= ConnectionConfiguration.getRemoteConnection();
				PreparedStatement deleteProduct= con.prepareStatement(query);
				deleteProduct.executeUpdate();
			} catch (SQLException e) {

				e.printStackTrace();
			}finally {
				if (con != null)
					isRemoteConnected = true;
				else{
					isRemoteConnected = false;
					fileWriter.writeQuery(query, "remoteDB.txt");
				}
			}
		}
        
    }
    
    public  void deleteComputer(String code) throws Exception{
		Connection con = null;
		updateDatabase();
		String query = "delete from computadoras where code= '"+ code+"'";
        	try {
           		con= ConnectionConfiguration.getConnectionLocal();
    			PreparedStatement deleteProduct= con.prepareStatement(query);
    			deleteProduct.executeUpdate();
    		} catch (SQLException e) {

            	e.printStackTrace();
    		} finally {
				if (con != null)
					isLocalConnected = true;
				else{
					isLocalConnected = false;
					fileWriter.writeQuery(query, "localDB.txt");
				}
				try {
					con= ConnectionConfiguration.getRemoteConnection();
					PreparedStatement deleteProduct= con.prepareStatement(query);
					deleteProduct.executeUpdate();
				} catch (SQLException e) {

					e.printStackTrace();
				}finally {
					if (con != null)
						isRemoteConnected = true;
					else{
						isRemoteConnected = false;
						fileWriter.writeQuery(query, "remoteDB.txt");
					}
				}
			}
	}
    
    public void restockPhone(String code, int newQuantity) throws Exception{

		Connection con = null;
		updateDatabase();
		String query = "Update celulares set quantity= '"+newQuantity+"' where code= '"+code+"'";
    	try {
       		con= ConnectionConfiguration.getConnectionLocal();
			PreparedStatement updatingProduct= con.prepareStatement(query);
			updatingProduct.executeUpdate();
		} catch (SQLException e) {

        	e.printStackTrace();
		} finally {
			if (con != null)
				isLocalConnected = true;
			else{
				isLocalConnected = false;
				fileWriter.writeQuery(query, "localDB.txt");
			}
			try {
				con= ConnectionConfiguration.getRemoteConnection();
				PreparedStatement updatingProduct= con.prepareStatement(query);
				updatingProduct.executeUpdate();
			} catch (SQLException e) {

				e.printStackTrace();
			}finally {
				if (con != null)
					isRemoteConnected = true;
				else{
					isRemoteConnected = false;
					fileWriter.writeQuery(query, "remoteDB.txt");
				}
			}
		}
	}
    
    public void restockComputer(String code, int newQuantity) throws Exception
	{

		Connection con = null;
		updateDatabase();
		String query = "Update computadoras set quantity= '"+newQuantity+"' where code= '"+code+"'";
    	try {
    		con= ConnectionConfiguration.getConnectionLocal();
			PreparedStatement updatingProduct= con.prepareStatement(query);
			updatingProduct.executeUpdate();
		} catch (SQLException e) {

        	e.printStackTrace();
		} finally {
			if (con != null)
				isLocalConnected = true;
			else{
				isLocalConnected = false;
				fileWriter.writeQuery(query, "localDB.txt");
			}
			try {
				con= ConnectionConfiguration.getRemoteConnection();
				PreparedStatement updatingProduct= con.prepareStatement(query);
				updatingProduct.executeUpdate();
			} catch (SQLException e) {

				e.printStackTrace();
			}finally {
				if (con != null)
					isRemoteConnected = true;
				else{
					isRemoteConnected = false;
					fileWriter.writeQuery(query, "remoteDB.txt");
				}
			}
		}
	}
    
    public void sellPhone(String code, int itemQuantity) throws Exception
	{

		Connection con;
    	try {
    		con= ConnectionConfiguration.getConnectionLocal();
			PreparedStatement updatingProduct= con.prepareStatement("Select * from celulares where code= '"+ code + "'");
			ResultSet resultSet;
			resultSet= updatingProduct.executeQuery();
			if (resultSet.next()) {
				int newQuantity= resultSet.getInt("quantity")-itemQuantity;
				if (newQuantity<itemQuantity) {
					return;
				}
				else {
					restockComputer(code, newQuantity);
					System.out.println(newQuantity);
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
        	e.printStackTrace();
		} finally {
			try {
				con= ConnectionConfiguration.getRemoteConnection();
				PreparedStatement updatingProduct= con.prepareStatement("Select * from celulares where code= '"+ code + "'");
				ResultSet resultSet;
				resultSet= updatingProduct.executeQuery();
				if (resultSet.next()) {
					int newQuantity= resultSet.getInt("quantity")-itemQuantity;
					if (newQuantity<itemQuantity) {
						return;
					}
					else {
						restockComputer(code, newQuantity);
						System.out.println(newQuantity);
					}
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}
    
    public void sellComputer(String code, int itemQuantity) throws Exception{

		Connection con;
    	try {
       		con= ConnectionConfiguration.getConnectionLocal();
			PreparedStatement updatingProduct= con.prepareStatement("Select * from computadoras where code= '"+ code + "'");
			ResultSet resultSet;
			resultSet= updatingProduct.executeQuery();
			if (resultSet.next()) {
				int newQuantity= resultSet.getInt("quantity") - itemQuantity;
				if (newQuantity<itemQuantity) {
					return;
				}
				else {
					restockComputer(code, newQuantity);
					System.out.println(newQuantity);
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
        	e.printStackTrace();
		} finally {
			try {
				con= ConnectionConfiguration.getRemoteConnection();
				PreparedStatement updatingProduct= con.prepareStatement("Select * from computadoras where code= '"+ code + "'");
				ResultSet resultSet;
				resultSet= updatingProduct.executeQuery();
				if (resultSet.next()) {
					int newQuantity= resultSet.getInt("quantity") - itemQuantity;
					if (newQuantity<itemQuantity) {
						return;
					}
					else {
						restockComputer(code, newQuantity);
						System.out.println(newQuantity);
					}
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
    
    public void updatePhone(String code, double newPrice) throws Exception{

		Connection con = null;
		updateDatabase();
		String query = "Update celulares set price= '"+newPrice+"' where code= '"+code+"'";
    	try {
       		con= ConnectionConfiguration.getConnectionLocal();
			PreparedStatement updatingProduct= con.prepareStatement(query);
			updatingProduct.executeUpdate();
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			if (con != null)
				isLocalConnected = true;
			else{
				isLocalConnected = false;
				fileWriter.writeQuery(query, "localDB.txt");
			}
			try {
				con= ConnectionConfiguration.getRemoteConnection();
				PreparedStatement updatingProduct= con.prepareStatement(query);
				updatingProduct.executeUpdate();
			} catch (SQLException e) {

				e.printStackTrace();
			}finally {
				if (con != null)
					isRemoteConnected = true;
				else{
					isRemoteConnected = false;
					fileWriter.writeQuery(query, "remoteDB.txt");
				}
			}
		}

	}
    
    public void updateComputer(String code, double newPrice) throws Exception{

		Connection con = null;
		updateDatabase();
		String query = "Update computadoras set price= '"+newPrice+"' where code= '"+code+"'";
    	try {
       		con= ConnectionConfiguration.getConnectionLocal();
			PreparedStatement updatingProduct= con.prepareStatement(query);
			updatingProduct.executeUpdate();
		} catch (SQLException e) {

        	e.printStackTrace();
		} finally {
			if (con != null)
				isLocalConnected = true;
			else{
				isLocalConnected = false;
				fileWriter.writeQuery(query, "localDB.txt");
			}
			try {
				con= ConnectionConfiguration.getRemoteConnection();
				PreparedStatement updatingProduct= con.prepareStatement(query);
				updatingProduct.executeUpdate();
			} catch (SQLException e) {
				e.printStackTrace();
			}finally {
				if (con != null)
					isRemoteConnected = true;
				else{
					isRemoteConnected = false;
					fileWriter.writeQuery(query, "remoteDB.txt");
				}
			}
    	}
    }

    public void updateDatabase()
	{
		try {
			if (isLocalConnected == true) {
				fileWriter.readQuery("localDB.txt", "local");
			}

			if (isRemoteConnected == true) {
				fileWriter.readQuery("remoteDB.txt", "remote");
			}
		} catch (Exception e){
			e.printStackTrace();
		}
	}
}
