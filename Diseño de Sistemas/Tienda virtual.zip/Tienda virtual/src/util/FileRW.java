package util;

import Tienda.ConnectionConfiguration;

import java.io.*;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class FileRW {

    private FileWriter file;
    private FileReader fileReader;
    private BufferedReader bufferedReader;
    private BufferedWriter bufferedWriter;

    public FileRW()
    {
        //nothing
    }

    public void openReader(String fileName)
    {
        try {
            fileReader = new FileReader(fileName);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        bufferedReader = new BufferedReader(fileReader);
    }

    public void closeWriter() throws IOException {
        bufferedWriter.close();
    }

    public void closeReader() throws IOException {
        bufferedReader.close();
    }

    public void writeQuery(String query, String fileName) throws IOException {
        File newFile = new File(fileName);
        try {
            file = new FileWriter(fileName, true);
            bufferedWriter = new BufferedWriter(file);
        } catch (IOException e) {
            System.out.println(e);
        }
        bufferedWriter.write(query + "\n");
        closeWriter();
    }

    public void readQuery(String fileName, String database) throws IOException {
        File queryFile = new File(fileName);
        openReader(fileName);
        String query;
        Connection con;
        PreparedStatement updatingQuery;

        if(queryFile.length() == 0)
            return;

        while ((query = bufferedReader.readLine()) != null)
        {
            if(database.equals("local"))
            {
                try {
                    con= ConnectionConfiguration.getConnectionLocal();
                    updatingQuery= con.prepareStatement(query);
                    updatingQuery.executeUpdate();
                } catch (Exception e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }else
            {
                try {
                    con= ConnectionConfiguration.getRemoteConnection();
                    updatingQuery= con.prepareStatement(query);
                    updatingQuery.executeUpdate();
                } catch (Exception e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        }

        closeReader();
        queryFile.delete();
    }
}
