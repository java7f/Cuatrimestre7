var menudata={children:[
{text:"Página principal",url:"index.html"},
{text:"Páginas relacionadas",url:"pages.html"},
{text:"Paquetes",url:"namespaces.html",children:[
{text:"Paquetes",url:"namespaces.html"}]},
{text:"Clases",url:"annotated.html",children:[
{text:"Lista de clases",url:"annotated.html"},
{text:"Jerarquía de la clase",url:"inherits.html"},
{text:"Miembros de las clases",url:"functions.html",children:[
{text:"Todo",url:"functions.html"},
{text:"Funciones",url:"functions_func.html"}]}]},
{text:"Archivos",url:"files.html",children:[
{text:"Lista de archivos",url:"files.html"}]}]}
