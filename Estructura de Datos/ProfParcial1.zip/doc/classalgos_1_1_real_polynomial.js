var classalgos_1_1_real_polynomial =
[
    [ "RealPolynomial", "classalgos_1_1_real_polynomial.html#a6adb61c14fd6a1e5eec98e744bd6f26c", null ],
    [ "RealPolynomial", "classalgos_1_1_real_polynomial.html#ac15cdb8ce0e39a09210d13f4abbf11f6", null ],
    [ "RealPolynomial", "classalgos_1_1_real_polynomial.html#ae71ffc5ac6ec3886f1b44eff6bd23a2b", null ],
    [ "degree", "classalgos_1_1_real_polynomial.html#ad98c69bbf65332b12980abd6ab6ab056", null ],
    [ "equal", "classalgos_1_1_real_polynomial.html#a05b9b9d6e9f32b716f6852cd21f72722", null ],
    [ "eval", "classalgos_1_1_real_polynomial.html#aa7c952451abb9ed22d040a4d2de805db", null ],
    [ "getCoef", "classalgos_1_1_real_polynomial.html#a08ceaf0ab3d952a827b9e07c23e2cd5c", null ],
    [ "setCoef", "classalgos_1_1_real_polynomial.html#ad84df02b259a51d32ab7210662eb3e97", null ],
    [ "sum", "classalgos_1_1_real_polynomial.html#aff2ff05dee07e2fb0f2f334c85f52808", null ]
];