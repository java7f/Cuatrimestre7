var classapps_1_1_test_polynomial =
[
    [ "main", "classapps_1_1_test_polynomial.html#af7a829742627c3c726fbae7b7dcded8b", null ]
];