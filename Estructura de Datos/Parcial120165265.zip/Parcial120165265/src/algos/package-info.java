/**
 * Paquete de algoritmos de polinomios.
 * @author Rodrigo Orizondo
 */
package algos;
