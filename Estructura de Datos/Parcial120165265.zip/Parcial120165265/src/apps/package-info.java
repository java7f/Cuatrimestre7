/**
 * Aplicaciones que usan polinomios.
 * @author Rodrigo Orizondo
 */
package apps;
