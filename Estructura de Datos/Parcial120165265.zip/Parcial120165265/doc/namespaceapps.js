var namespaceapps =
[
    [ "TestPolynomial", "classapps_1_1_test_polynomial.html", "classapps_1_1_test_polynomial" ]
];