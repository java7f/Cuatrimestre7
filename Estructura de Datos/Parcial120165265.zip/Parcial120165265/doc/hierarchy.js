var hierarchy =
[
    [ "algos.PolynomialInterface", "interfacealgos_1_1_polynomial_interface.html", [
      [ "algos.RealPolynomial", "classalgos_1_1_real_polynomial.html", null ]
    ] ],
    [ "apps.TestPolynomial", "classapps_1_1_test_polynomial.html", null ]
];