var namespaces =
[
    [ "algos", "namespacealgos.html", null ],
    [ "apps", "namespaceapps.html", null ]
];