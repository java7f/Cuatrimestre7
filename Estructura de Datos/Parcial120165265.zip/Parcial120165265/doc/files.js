var files =
[
    [ "algos/package-info.java", "algos_2package-info_8java.html", null ],
    [ "apps/package-info.java", "apps_2package-info_8java.html", null ],
    [ "PolynomialInterface.java", "_polynomial_interface_8java.html", [
      [ "PolynomialInterface", "interfacealgos_1_1_polynomial_interface.html", "interfacealgos_1_1_polynomial_interface" ]
    ] ],
    [ "RealPolynomial.java", "_real_polynomial_8java.html", [
      [ "RealPolynomial", "classalgos_1_1_real_polynomial.html", "classalgos_1_1_real_polynomial" ]
    ] ],
    [ "TestPolynomial.java", "_test_polynomial_8java.html", [
      [ "TestPolynomial", "classapps_1_1_test_polynomial.html", "classapps_1_1_test_polynomial" ]
    ] ]
];