var namespaces =
[
    [ "apps", "namespaceapps.html", null ],
    [ "genericgraphs", "namespacegenericgraphs.html", null ]
];