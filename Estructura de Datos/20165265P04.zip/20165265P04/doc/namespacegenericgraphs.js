var namespacegenericgraphs =
[
    [ "AdjList", "classgenericgraphs_1_1_adj_list.html", "classgenericgraphs_1_1_adj_list" ],
    [ "DGraph", "classgenericgraphs_1_1_d_graph.html", "classgenericgraphs_1_1_d_graph" ],
    [ "UGraph", "classgenericgraphs_1_1_u_graph.html", "classgenericgraphs_1_1_u_graph" ],
    [ "UIntGraphsPers", "classgenericgraphs_1_1_u_int_graphs_pers.html", "classgenericgraphs_1_1_u_int_graphs_pers" ]
];