var NAVTREE =
[
  [ "20165265P04", "index.html", [
    [ "Paquetes", null, [
      [ "Paquetes", "namespaces.html", "namespaces" ]
    ] ],
    [ "Clases", "annotated.html", [
      [ "Lista de clases", "annotated.html", "annotated_dup" ],
      [ "Jerarquía de la clase", "hierarchy.html", "hierarchy" ],
      [ "Miembros de las clases", "functions.html", [
        [ "Todo", "functions.html", null ],
        [ "Funciones", "functions_func.html", null ]
      ] ]
    ] ],
    [ "Archivos", null, [
      [ "Lista de archivos", "files.html", "files" ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"_adj_list_8java.html"
];

var SYNCONMSG = 'click en deshabilitar sincronización';
var SYNCOFFMSG = 'click en habilitar sincronización';