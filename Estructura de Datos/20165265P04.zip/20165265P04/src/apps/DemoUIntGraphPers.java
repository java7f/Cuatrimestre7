/**
 * @file DemoUIntGraphPers.java
 * @brief Fuente de la aplicación de consola que prueba la clase UIntGraphPers.
 */
package apps;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Iterator;
import java.util.TreeSet;

import genericgraphs.UGraph;
import genericgraphs.UIntGraphsPers;

/**
 * Clase que ejecuta pruebas sobre la carga de data
 * de un archivo a un grafo.
 * @author java7f
 *
 */
public class DemoUIntGraphPers {
	
	/**
	 * Función que valida si el archivo existe y, en caso de existir, si su estructura 
	 * es correcta.
	 * @param filePath Path del archivo con la data.
 	 * @return False si el archivo no es válido.
	 * @throws IOException Si hubo error al leer.
	 * @throws FileNotFoundException Si el archivo no existe.
	 */
	public static boolean isValid(String filePath) throws IOException {
		BufferedReader reader = null;
		
		try {
			 reader = new BufferedReader(new FileReader(filePath));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		String line;
		String[] numbers;
		
		while ((line = reader.readLine()) != null) {
			numbers = line.split(",");
			
			//Se chequea si en vez de separación por comas, se usó separación por espacios.
			if (numbers.length < 2) {
				if(numbers[0].contains(" "))
				{
					return false;
				}
			}
			
			//Se chequea que no haya más de dos números.
			if (numbers.length > 2) {
				return false;
			}
		}
		
		return true;
	}
	
	/**
	 * Función que enumera los vértices en el grafo e imprime el valor que aloja.
	 * @param graph grafo armado.
	 */
	public static void enumVertices(UGraph<Integer> graph) {
		TreeSet<Integer> vertices = graph.getVertices();
		Iterator<Integer> iterator = vertices.iterator();
		Integer currentVertex, counter = 1;
		
		while (iterator.hasNext()) {
			currentVertex = iterator.next();
			System.out.println("Vértice " + counter + " contiene el valor " + currentVertex);
			counter++;
		}
	}
	
	public static void enumEdges(UGraph<Integer> graph) {
		
	}
	
	/**
	 * Punto de entrada de la aplicación.
	 * @param args Path del archivo
	 * @throws IOException si hubo un error de lectura en el archivo.
	 */
	public static void main(String[] args) throws IOException {
		UGraph<Integer> graph = new UGraph<>();
		UIntGraphsPers loader = new UIntGraphsPers();
		
		if(!isValid(args[0]))
		{
			System.out.println("El archivo no es válido.");
		}
		else {

			try {
				graph = loader.loadGraph(args[0]);
			} catch (IOException e) {
				e.printStackTrace();
			}
			
			enumVertices(graph);
		}
		
	}
}
