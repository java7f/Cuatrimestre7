/**
 * @file AdjList.java
 * @brief Fuente de la clase genérica AdjList
 */
package genericgraphs;

import java.util.TreeSet;

/**
 * Clase representativa de una lista de adyacencia.
 * @remarks La lista de adyacencia está realizada actualmente
 * 			mediante un TreeSet.
 * @author Rodrigo Orizondo
 * @since 18/10/2013 21:03:11
 * @param <V> Tipo de los vértices alojados en la lista de adyacencia.
 */
public class AdjList <V extends Comparable<V>> {
	TreeSet<V> adj;
	
	/**
	 * Retorna una copia de la lista de adyacencia.
	 * @return Copia de la lista de adyacencia o null si hubo error en la copia.
	 * @author Rodrigo Orizondo
	 * @since Nov 8, 2013 9:47:55 PM
	 */
	public TreeSet<V> getAdj() {
		TreeSet<V> aux= new TreeSet<V>();
		for ( V v : adj ) {
			if ( !aux.add(v) )
				return null;
		}
		return aux;
	}

	/**
	 * Indaga si la lista de adyacencia está vacía.
	 * @return true si está vacía.
	 * @since Nov 13, 2013 12:50:34 PM
	 */
	public Boolean isEmpty() {
		return adj.isEmpty();
	}
	
	/**
	 * Obtiene la cantidad de vértices en la lista de adyacencia.
	 * @return Cantidad de vértices en la lista de adyacencia.
	 */
	public int size() {
		return adj.size();
	}
	
	/**
	 * Constructor que crea una lista de adyacencia vacía.
	 * @author Manuel González
	 * @since 18/10/2013 21:36:44
	 */
	public AdjList() {
		adj= new TreeSet<V>();
	}
	
	/**
	 * Constructor que crea una lista de adyacencia inicializada con un vertice. 
	 * @param v  Vertice con el que se inicializa la lista de adyacencia. 
	 * @author Priscilla Vargas
	 * @since 18/10/2013 21:43:38
	 */
	public AdjList(V v) {
		adj= new TreeSet<V>();
		adj.add(v);
	}

	/** 
	 * Agrega un vértice a la lista de adyacencia. 
	 * 
	 * @param v Vértice de tipo V a agregar a la lista. 
	 * @return true si no agregó. 
	 * @author Edgar E. Rodriguez M 
	 * @date Nov 8, 2013 9:37:02 PM 
	 */
	 public Boolean addVert(V v) { 
		 return !adj.add(v); 
	 }

	/** 
	 * Método para remover un vértice de la lista de adyacencia. 
	 *
	 * @author Emmanuel Vásquez  
	 * @param delVert Vértice a borrar. 
	 * @return false si el vertice es removido o true si no lo es.  
	 * @date Nov 1, 2013 8:43:52 PM  
	*/ 
	public boolean deleteVert(V delVert) { 
		return !adj.remove(delVert); 
	}
	
	/** 
	 * Chequea la existencia de un vértice en la lista de adyacencia. 
	 *  
	 * @author Marcos Rojas 
	 * @param v Vértice a chequear.  
	 * @since Nov 8, 2013 8:36:06 PM  
	 * @return true si el vértice existe o false si no. 
	 */ 
	public Boolean exist(V v) { 
		return adj.contains(v); 
	}
}
