/**
 * @file UIntGraphsPers.java
 * @brief Fuente de la clase que carga un archivo a un grafo.
 */
package genericgraphs;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

/**
 * Clase que representa la carga de la data de un archivo en un grafo,
 * siempre y cuando el formato del archivo sea correcto.
 * @author java7f
 *
 */
public class UIntGraphsPers {

	/**
	 * Grafo que se formará a partir del archivo.
	 */
	UGraph<Integer> graph;
	
	/**
	 * Instancia la clase sin información.
	 */
	public UIntGraphsPers() {
		graph = new UGraph<>();
	}
	
	/**
	 * Función que carga la data de un archivo a un grafo.
	 * @param filePath Path del archivo que contiene la data.
	 * @return Grafo cargado
	 * @throws IOException Cuando no se encuentra el archivo o hay un error de I/O.
	 */
	public UGraph<Integer> loadGraph(String filePath) throws IOException {
		BufferedReader reader = new BufferedReader(new FileReader(filePath));
		String edge;
		String[] vertices;
		Integer vertex1, vertex2;
		
		while ((edge = reader.readLine()) != null) {
			vertices = edge.split(",");
			if(vertices.length < 2)
			{
				graph.addVertex(Integer.parseInt(vertices[0]));
			}
			else
			{
				vertex1 = Integer.parseInt(vertices[0]);
				vertex2 = Integer.parseInt(vertices[1]);
				graph.addVertex(vertex1);
				graph.addVertex(vertex2);
				graph.delEdge(vertex1, vertex2);
			}
		}
		reader.close();
		return graph;
	}
}
