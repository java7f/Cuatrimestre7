/**
 * @file DGraph.java
 * @brief Fuente de la clase genérica DGraph
 */
package genericgraphs;

import java.util.HashMap;
import java.util.TreeSet;

/**
 * Clase genérica representativa de un grafo orientado.
 * @author Rodrigo Orizondo
 * @since 18/10/2013 21:03:11
 * @param <V> Tipo de los vértices alojados en el grafo.
 */
public class DGraph <V extends Comparable<V>> {
	
	/**
	 * Mantiene y representa los elementos constitutivos de un grafo.
	 * 
	 * @remarks La representación está dada por el par
	 * 			(vértices, aristas) donde los vértices del grafo son
	 * 			las llaves del HashMap y las aristas están representadas
	 * 			mediante una lista de adyacencia AdjList.
	 * @date Oct 19, 2013 6:52:29 AM
	 */
	HashMap<V, AdjList<V>> grafo;
	
	/**
	 * Constructor de un grafo vacío.
	 * @author Rodrigo Orizondo
	 */
	public DGraph() {
		grafo= new HashMap<V, AdjList<V>>();
	}
	
	/**
	 * Indaga si el grafo está vacío.
	 * @return true si está vacía.
	 * @since Nov 13, 2013 12:50:34 PM
	 */
	public Boolean isEmpty() {
		return grafo.isEmpty();
	}
	
	/** 
	* Método que agrega un vértice al grafo.  
	*   
	* @author Talal Dauhajre  
	* @date Nov 8, 2013 4:08:29 PM  
	* @param v Vértice que se va a agregar.
	* @return true si no se pudo agregar.   
	*/  
	public Boolean addVertex(V v) {
		if ( !exist(v) ) {
			grafo.put(v, new AdjList<V>());
			return false;
		}
		return true;
	}
	
	/** 
	 * Método para agregar una arista. 
	 * @author Joel Agustin Rosario Lopez, Priscilla Vargas   
	 * @since Nov 1, 2013 8:48:25 PM 
	 * @param v1 Vértice inicial.
	 * @param v2 Vértice final.
	 * @return	true si uno de los vértices no existe en el grafo. 
	 * 			false si la arista fue agregada exitosamente. 
	 */ 
	 public boolean addEdge(V v1, V v2) { 
		 if ( exist(v1) && exist(v2) ) { 
			 return grafo.get(v1).addVert(v2);
		 } 
		 else  
			 return true; 
	 }
	 
	 /**
	 * Método para la eliminación de un vértice.
	 * @author José Rafael Luciano
	 * @since Nov 1, 2013 8:24:17 PM
	 * @param v Vertice a eliminar
	 * @return true si el vértice ya estaba ausente del grafo.
	 * @warning El código corrigen un bug severo en el original
	 * @author Rodrigo Orizondo
	 * @date Nov 14, 2013 11:24:30 AM
	 */
	public Boolean delVertex(V v) {
		if ( grafo.remove(v) == null )
			return true;
		// Eliminar todas las posibles presencias de v en las listas
		// de adyacencia supervivientes.
		for ( V vert : grafo.keySet() ) {
			grafo.get(vert).deleteVert(v);
		}
		return false;
	}
	
	/** 
	 * Elimina la arista que conecta los vértices v1 y v2 
	 * @author		Jorge I. Canario O. 
	 * @date		Nov 8, 2013 9:48:10 AM 
	 * @param v1	Vértice inicial. 
	 * @param v2	Vértice final. 
	 * @return	Retorna false si logra eliminar exitosamente la arista,
	 * 			true en caso contrario 
	*/ 
	public boolean delEdge(V v1, V v2) { 
		return !(exist(v1,v2) && !(grafo.get(v1).deleteVert(v2))); 
	}
	
	/**
	 * Método para comprobar si existe un vertice.
	 * 
	 * @author Carlos Cabreja
	 * @date Nov 1, 2013 8:28:22 PM
	 * @param v Vertice a comprobar
	 * @return	El método retorna true si el vertice dado existe.
	 */
	public boolean exist(V v) {
		return grafo.containsKey(v);
	}

	/**
	 * Comprueba la existencia de una arista entre v1 y v2
	 * @author JHONNEL F. APOLINARIO C.
	 * @date Nov 1, 2013 8:38:20 PM
	 * @param v1 Vértice inicial.
	 * @param v2 Vértice final.
	 * @return Retorna true si exite una arista de v1 a v2.
	 * 
	 */
	public boolean exist(V v1, V v2) {
		return exist(v1) && getAdjList(v1).exist(v2);
	}
	
	/**
	 * Obtiene los vértices presentes en el grafo.
	 * @return TreeSet con los vértices en el grafo o null si hubo error.
	 * @date Oct 25, 2013 11:04:22 PM
	 */
	public TreeSet<V> getVertices() {
		TreeSet<V> all= new TreeSet<V>();
		for ( V v : grafo.keySet() ) {
			if ( !all.add(v) )
				return null;
		}
		return all;
	}
	
	/**
	 * Obtiene los vértices adyacentes de uno dado.
	 * @date Nov 01, 2013 8:24:22 PM
	 * @param v Vértice del grafo.
	 * @return	Una lista de adyacencia con los vértices adyacentes
	 * 			o null si hubo error.
	 * @remark	Pudiera ocurrir que la lista de adyacencia estuviese vacía.
	 */
	public AdjList<V> getAdjList(V v) {
		AdjList<V> adjs= new AdjList<V>();
		AdjList<V> presents= grafo.get(v);
		for ( V n : presents.getAdj() ) {
			if ( adjs.addVert(n) )
				return null;
		}
		return adjs;
	}
}
