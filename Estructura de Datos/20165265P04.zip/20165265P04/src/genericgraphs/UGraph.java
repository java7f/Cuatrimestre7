/**
 * @file UGraph.java
 * @brief Fuente de la clase UGraph.
 */
package genericgraphs;

/**
 * Clase genérica representativa de un grafo NO orientado.
 * @author Rodrigo Orizondo
 * @since Nov 14, 2013 11:01:51 AM
 * @param <V> Tipo de los vértices alojados en el grafo.
 * @remarks		La realización del grafo no orientado consiste en
 * 				realizar uno orientado donde cada arista tiene su recíproco.
 */
public class UGraph<V extends Comparable<V>> extends DGraph<V> {
	/**
	 * Constructor de un grafo vacío.
	 * @author Rodrigo Orizondo
	 * @remarks La inicialización es idéntica a la del grafo orientado.
	 */
	public UGraph() {
		super();
	}
	
	/**
	 * @see genericgraph.DGraph#addEdge(java.lang.Comparable, java.lang.Comparable)
	 * @warning Para los grafos no orientados no se admiten auto referencias.
	 * @since Nov 14, 2013 11:34:22 AM
	 */
	@Override
	public boolean addEdge(V v1, V v2) {
		if ( v1 == v2 )
			return true;
		if ( super.addEdge(v1, v2)) {
			return true;
		}
		if ( super.addEdge(v2, v1) ) {
			super.delEdge(v1, v2); // Roll-back
			return true;
		}
		return false;
	}

	/**
	 * @see genericgraph.DGraph#delEdge(java.lang.Comparable, java.lang.Comparable)
	 * @remark Se elimina la pareja de aristas orientadas.
	 */
	@Override
	public boolean delEdge(V v1, V v2) {
		if ( super.delEdge( v1, v2) )
			return true;
		if ( super.delEdge( v1, v2) ) {
			super.addEdge(v1, v2); // Roll-back
			return true;
		}
		return false;
	}
	
}
