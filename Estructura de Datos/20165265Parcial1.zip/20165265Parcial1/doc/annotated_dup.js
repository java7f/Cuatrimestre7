var annotated_dup =
[
    [ "algos", "namespacealgos.html", "namespacealgos" ],
    [ "apps", "namespaceapps.html", "namespaceapps" ]
];