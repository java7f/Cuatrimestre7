var namespacealgos =
[
    [ "PolynomialInterface", "interfacealgos_1_1_polynomial_interface.html", "interfacealgos_1_1_polynomial_interface" ],
    [ "RealPolynomial", "classalgos_1_1_real_polynomial.html", "classalgos_1_1_real_polynomial" ]
];