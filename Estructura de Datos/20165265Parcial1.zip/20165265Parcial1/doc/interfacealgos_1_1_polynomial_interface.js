var interfacealgos_1_1_polynomial_interface =
[
    [ "degree", "interfacealgos_1_1_polynomial_interface.html#a3bc6549d530ca9ed8a2301e6ff152a5c", null ],
    [ "equal", "interfacealgos_1_1_polynomial_interface.html#a1275275e834cd11eba592bb7b0093e09", null ],
    [ "eval", "interfacealgos_1_1_polynomial_interface.html#a26fe738f16212028c3870bede0309eb3", null ],
    [ "getCoef", "interfacealgos_1_1_polynomial_interface.html#a45d1a6c4be7aea8683fbdf0528de9fdf", null ],
    [ "setCoef", "interfacealgos_1_1_polynomial_interface.html#a1c1a2b1d4270fc61f3476a38c5c58d55", null ],
    [ "sum", "interfacealgos_1_1_polynomial_interface.html#a8a8023682538746912d285e0ac244213", null ]
];