package app;
import base.Matrix;
import sequential.SequentialMatrix;
import app.Timer;
import base.MatrixTimeRegister;

public class Main {

	public static void main(String[] args) {
		
		//se crea el timer que se va a encargar de medir el tiempo de ejecucion
		MatrixTimeRegister timeRegister = new MatrixTimeRegister();
		
		//se crean las matrices a partir de los valores en los archivos especificados
		Matrix x10A = new SequentialMatrix(10, 10, "10x10A.txt");
		Matrix x10B = new SequentialMatrix(10, 10, "10x10B.txt");
		Matrix x20A = new SequentialMatrix(20, 20, "20x20A.txt");
		Matrix x20B = new SequentialMatrix(20, 20, "20x20B.txt");
		Matrix x30A = new SequentialMatrix(30, 30, "30x30A.txt");
		Matrix x30B = new SequentialMatrix(30, 30, "30x30B.txt");
		Matrix x40A = new SequentialMatrix(40, 40, "40x40A.txt");
		Matrix x40B = new SequentialMatrix(40, 40, "40x40B.txt");
		Matrix x50A = new SequentialMatrix(50, 50, "50x50A.txt");
		Matrix x50B = new SequentialMatrix(50, 50, "50x50B.txt");
		Matrix x60A = new SequentialMatrix(60, 60, "60x60A.txt");
		Matrix x60B = new SequentialMatrix(60, 60, "60x60B.txt");
		Matrix x70A = new SequentialMatrix(70, 70, "70x70A.txt");
		Matrix x70B = new SequentialMatrix(70, 70, "70x70B.txt");
		Matrix x80A = new SequentialMatrix(80, 80, "80x80A.txt");
		Matrix x80B = new SequentialMatrix(80, 80, "80x80B.txt");
		Matrix x90A = new SequentialMatrix(90, 90, "90x90A.txt");
		Matrix x90B = new SequentialMatrix(90, 90, "90x90B.txt");
		Matrix x100A = new SequentialMatrix(100, 100, "100x100A.txt");
		Matrix x100B = new SequentialMatrix(100, 100, "100x100B.txt");
		
		//se le indica en que archivo va a guardar los tiempos
		timeRegister.openWriter("time_register.txt");
		
		timeRegister.registerTime(x10A, x10B);
		timeRegister.registerTime(x20A, x20B);
		timeRegister.registerTime(x30A, x30B);
		timeRegister.registerTime(x40A, x40B);
		timeRegister.registerTime(x50A, x50B);
		timeRegister.registerTime(x60A, x60B);
		timeRegister.registerTime(x70A, x70B);
		timeRegister.registerTime(x80A, x80B);
		timeRegister.registerTime(x90A, x90B);
		timeRegister.registerTime(x100A, x100B);
		
		timeRegister.closeWriter();
		
		
		
		
	}

}
